import * as React from 'react';
import { IProjectManagementProps } from './IProjectManagementProps';
import "@pnp/sp/webs";
import "@pnp/sp/profiles";
export default class ProjectManagement extends React.Component<IProjectManagementProps, any> {
    private _sp;
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IProjectManagementProps>;
    private _getMyDetails;
}
//# sourceMappingURL=ProjectManagement.d.ts.map