declare const styles: {
    projectManagement: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    NavHeader: string;
    header: string;
    headerImage: string;
    userTitle: string;
    userImage: string;
    userDetails: string;
};
export default styles;
//# sourceMappingURL=ProjectManagement.module.scss.d.ts.map