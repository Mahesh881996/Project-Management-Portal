import * as React from 'react';
import { IProjectManagementProps } from '../IProjectManagementProps';
export default class Home extends React.Component<any, any> {
    render(): React.ReactElement<IProjectManagementProps>;
}
//# sourceMappingURL=Home.d.ts.map