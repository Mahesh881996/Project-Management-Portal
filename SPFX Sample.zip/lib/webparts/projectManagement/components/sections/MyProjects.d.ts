import * as React from 'react';
import { IProjectManagementProps } from '../IProjectManagementProps';
import { MyProjectsState } from './States/MyProjectsState';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';
export default class MyProjects extends React.Component<IProjectManagementProps, MyProjectsState> {
    constructor(props: any);
    getProjectsData(): Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<IProjectManagementProps>;
}
//# sourceMappingURL=MyProjects.d.ts.map