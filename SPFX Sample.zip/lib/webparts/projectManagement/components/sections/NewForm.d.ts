import * as React from 'react';
import { IProjectManagementProps } from '../IProjectManagementProps';
import { NewFormStates } from './States/NewFormState';
export default class NewForm extends React.Component<IProjectManagementProps, NewFormStates> {
    constructor(props: any);
    private handleChange;
    private createProject;
    private newProject;
    render(): React.ReactElement<IProjectManagementProps>;
}
//# sourceMappingURL=NewForm.d.ts.map