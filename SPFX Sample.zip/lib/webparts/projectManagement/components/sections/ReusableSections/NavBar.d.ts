import * as React from "react";
export default class Navigation extends React.Component {
    render(): JSX.Element;
}
//# sourceMappingURL=NavBar.d.ts.map