export interface MyProjectsState {
    projects?: any;
    columns?: any;
}
//# sourceMappingURL=MyProjectsState.d.ts.map