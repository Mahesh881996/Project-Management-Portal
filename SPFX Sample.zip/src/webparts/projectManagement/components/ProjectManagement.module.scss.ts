/* tslint:disable */
require("./ProjectManagement.module.css");
const styles = {
  projectManagement: 'projectManagement_100c7f5f',
  teams: 'teams_100c7f5f',
  welcome: 'welcome_100c7f5f',
  welcomeImage: 'welcomeImage_100c7f5f',
  links: 'links_100c7f5f',
  NavHeader: 'NavHeader_100c7f5f',
  header: 'header_100c7f5f',
  headerImage: 'headerImage_100c7f5f',
  userTitle: 'userTitle_100c7f5f',
  userImage: 'userImage_100c7f5f',
  userDetails: 'userDetails_100c7f5f'
};

export default styles;
/* tslint:enable */