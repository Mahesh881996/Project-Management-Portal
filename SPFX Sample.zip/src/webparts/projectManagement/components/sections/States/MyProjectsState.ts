import { IAttachmentFileInfo } from "@pnp/sp/attachments/types";

export interface MyProjectsState {
    projects ?: any;
    columns ?: any;
}
  